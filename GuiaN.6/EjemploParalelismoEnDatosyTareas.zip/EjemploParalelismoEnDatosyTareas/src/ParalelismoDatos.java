/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author yefer
 */
import java.util.concurrent.RecursiveTask;
import java.util.concurrent.ForkJoinPool;

public class ParalelismoDatos {
    
    static class SumaParalela extends RecursiveTask<Integer> {
        private final int[] array;
        private final int inicio, fin;
        private static final int LIMITE = 2;

        public SumaParalela(int[] array, int inicio, int fin) {
            this.array = array;
            this.inicio = inicio;
            this.fin = fin;
        }

        @Override
        protected Integer compute() {
            if (fin - inicio <= LIMITE) {
                int suma = 0;
                for (int i = inicio; i < fin; i++) {
                    suma += array[i];
                }
                return suma;
            } else {
                int medio = (inicio + fin) / 2;
                SumaParalela tareaIzquierda = new SumaParalela(array, inicio, medio);
                SumaParalela tareaDerecha = new SumaParalela(array, medio, fin);

                tareaIzquierda.fork(); 
                int sumaDerecha = tareaDerecha.compute(); 
                int sumaIzquierda = tareaIzquierda.join(); 

                return sumaIzquierda + sumaDerecha;
            }
        }
    }

    public static void main(String[] args) {
        ForkJoinPool pool = new ForkJoinPool();
        int[] array = {1, 2, 3, 4, 5, 6, 7, 8};

        SumaParalela tarea = new SumaParalela(array, 0, array.length);
        int resultado = pool.invoke(tarea);

        System.out.println("Resultado final de la suma: " + resultado);
    }
}
