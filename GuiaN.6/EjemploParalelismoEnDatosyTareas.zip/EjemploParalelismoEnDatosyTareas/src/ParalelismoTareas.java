/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author yefer
 */
public class ParalelismoTareas {
    
       static class ProcesarTexto implements Runnable {
        private String texto;

        public ProcesarTexto(String texto) {
            this.texto = texto;
        }

        @Override
        public void run() {
            String resultado = texto.toUpperCase();
            System.out.println("Texto procesado: " + resultado);
        }
    }

    static class ProcesarNumeros implements Runnable {
        private int[] numeros;

        public ProcesarNumeros(int[] numeros) {
            this.numeros = numeros;
        }

        @Override
        public void run() {
            int suma = 0;
            for (int num : numeros) {
                suma += num;
            }
            System.out.println("Suma de numeros: " + suma);
        }
    }

    public static void main(String[] args) {
        String texto = "hola";
        int[] numeros = {1, 2, 3, 4, 5};

        Thread hiloTexto = new Thread(new ProcesarTexto(texto));
        Thread hiloNumeros = new Thread(new ProcesarNumeros(numeros));

        hiloTexto.start();
        hiloNumeros.start();

        try {
            hiloTexto.join();
            hiloNumeros.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
